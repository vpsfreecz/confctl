require_relative 'command'
require_relative '../hook'
require 'json'
require 'rainbow'
require 'shellwords'
require 'tty-pager'
require 'tty-progressbar'
require 'tty-spinner'

module ConfCtl::Cli
  class Cluster < Command
    ConfCtl::Hook.register :cluster_deploy

    def list
      if opts[:list]
        prefix = 'cluster.<name>.'
        nix = ConfCtl::Nix.new

        puts 'name'

        nix.module_options.each do |opt|
          next unless opt['name'].start_with?(prefix)

          puts opt['name'][prefix.length..]
        end

        return
      end

      list_machines(select_machines_with_managed(args[0]))
    end

    def build
      machines = select_machines(args[0]).managed

      raise 'No machines to build' if machines.empty?

      ask_confirmation! do
        puts 'The following machines will be built:'
        list_machines(machines)
      end

      do_build(machines)
    end

    def deploy
      machines = select_machines(args[0]).managed
      action = args[1] || 'switch'

      raise GLI::BadCommandLine, "invalid action '#{action}'" unless %w[boot switch test dry-activate].include?(action)

      if opts[:reboot]
        raise GLI::BadCommandLine, '--reboot can be used only with switch-action boot' if action != 'boot'

        parse_wait_online
      end

      raise 'No machines to deploy' if machines.empty?

      ask_confirmation! do
        puts 'The following machines will be deployed:'
        list_machines(machines)
        puts
        puts "Generation: #{opts[:generation] || 'new build'}"
        puts "Target action: #{action}#{' + reboot' if opts[:reboot]}"
      end

      ConfCtl::Hook.call(:cluster_deploy, kwargs: {
        machines:,
        generation: opts[:generation],
        action: opts[:action],
        opts:
      })

      host_generations =
        if opts[:generation]
          find_generations(machines, opts[:generation])
        else
          do_build(machines)
        end

      nix = ConfCtl::Nix.new(show_trace: opts['show-trace'])
      machines, host_generations = skip_current_deploy_targets(machines, host_generations, action)

      return if host_generations.empty?

      if opts['one-by-one']
        deploy_one_by_one(machines, host_generations, nix, action)
      else
        deploy_in_bulk(machines, host_generations, nix, action)
      end
    end

    def health_check
      machines = select_machines(args[0]).managed.runnable.select do |_host, machine|
        machine.health_checks.any?
      end
      raise 'No runnable machines to check or no health checks configured' if machines.empty?

      run_checks = machines.health_checks

      ask_confirmation! do
        puts 'Health checks will be run on the following machines:'

        list_machines(machines, prepend_cols: %w[checks])
        puts
        puts "#{run_checks.length} checks in total"
        puts
      end

      return unless run_health_checks(machines, run_checks).any?

      raise 'Health checks failed'
    end

    def status
      machines = select_machines(args[0]).managed.select do |_host, machine|
        machine.target_host || machine.carried?
      end

      raise 'No machines to check' if machines.empty?

      ask_confirmation! do
        if opts[:generation]
          puts 'The following machines will be checked:'
        else
          puts 'The following machines will be built and then checked:'
        end

        list_machines(machines)
        puts
        puts "Generation: #{opts[:generation] || 'new build'}"
      end

      statuses = machines.transform_values do |machine|
        ConfCtl::MachineStatus.new(machine)
      end

      if opts[:generation] == 'none'
        host_generations = nil
      elsif opts[:generation]
        host_generations = find_generations(machines, opts[:generation])

        # Ignore statuses when no generation was found
        statuses.delete_if do |host, _st|
          !host_generations.has_key?(host)
        end
      else
        host_generations = do_build(machines)
        puts
      end

      if host_generations
        host_generations.each do |host, gen|
          statuses[host].target_toplevel = gen.toplevel
        end
      end

      assign_target_inputs_info(
        statuses,
        host_generations: opts[:generation] && opts[:generation] != 'none' ? host_generations : nil
      )

      tw = ConfCtl::ParallelExecutor.new(machines.length)

      statuses.each_value do |st|
        tw.add do
          st.query(toplevel: opts[:generation] != 'none', inputs: true)
        end
      end

      tw.run

      roles = inputs_roles_for_status(statuses)
      rows = []
      cols = %w[host online uptime status generations] + roles

      statuses.each do |host, st|
        build_generations = ConfCtl::Generation::BuildList.new(host)
        online = st.uptime ? true : false

        inputs_ok = inputs_ok?(st)
        status_ok = online && inputs_ok
        status_ok &&= st.target_toplevel == st.current_toplevel if st.target_toplevel

        row = {
          'host' => host,
          'online' => online && Rainbow('yes').green,
          'uptime' => st.uptime && format_duration(st.uptime),
          'status' => status_ok ? Rainbow('ok').green : Rainbow('outdated').red,
          'generations' => "#{build_generations.count}:#{st.generations && st.generations.count}"
        }

        roles.each do |role|
          t_info = st.target_inputs_info && st.target_inputs_info[role]
          d_info = st.inputs_info && st.inputs_info[role]
          state = inputs_info_state(t_info, d_info)
          row[role] = format_inputs_state(state, d_info)
        end

        rows << row
      end

      OutputFormatter.print(rows, cols, layout: :columns, color: use_color?)
    end

    def changelog
      compare_inputs_info do |io, host, target_info, deployed_info|
        roles = inputs_roles(target_info, deployed_info)
        if roles.empty?
          io.puts "#{host}: no inputs info"
          io.puts ''
          next
        end

        entries = inputs_info_entries(target_info, deployed_info, pattern: args[1])
        next if entries.empty?

        any_changed = false
        any_unknown = false

        entries.each do |entry|
          role = entry[:role]
          t_info = entry[:target]
          d_info = entry[:deployed]

          case entry[:status]
          when :unknown
            any_unknown = true
            io.puts "#{host} @ #{role} in unknown state"
          when :changed
            any_changed = true
            io.puts "#{host} @ #{role}:"

            begin
              log = inputs_git_log(t_info, d_info)
              io.puts(log || '(changelog unavailable)')
            rescue StandardError => e
              io.puts e.message
            end

            io.puts ''
          end
        end

        unless any_changed || any_unknown
          io.puts "#{host}: no changes"
          io.puts ''
        end

        io.puts '' if any_unknown && !any_changed
      end
    end

    def diff
      compare_inputs_info do |io, host, target_info, deployed_info|
        roles = inputs_roles(target_info, deployed_info)
        if roles.empty?
          io.puts "#{host}: no inputs info"
          io.puts ''
          next
        end

        entries = inputs_info_entries(target_info, deployed_info, pattern: args[1])
        next if entries.empty?

        any_output = false

        entries.each do |entry|
          role = entry[:role]
          t_info = entry[:target]
          d_info = entry[:deployed]

          case entry[:status]
          when :unknown
            any_output = true
            io.puts "#{host} @ #{role} in unknown state"
          when :changed
            any_output = true
            from = inputs_short_rev(d_info) || 'unknown'
            to = inputs_short_rev(t_info) || 'unknown'
            from, to = to, from if opts[:downgrade]
            url = inputs_url(t_info, d_info)
            label = url ? "#{role} (#{url})" : role
            io.puts "#{host} @ #{label}: #{from} -> #{to}"
          end
        end

        unless any_output
          io.puts "#{host}: no changes"
        end

        io.puts ''
      end
    end

    def test_connection
      machines = select_machines_with_managed(args[0]).runnable
      raise 'No machines to test' if machines.empty?

      ask_confirmation! do
        puts 'Test SSH connection to the following machines:'
        list_machines(machines)
      end

      succeeded = []
      failed = []

      machines.each do |host, machine|
        mc = ConfCtl::MachineControl.new(machine)

        begin
          mc.test_connection
          succeeded << host
        rescue TTY::Command::ExitError => e
          puts "Unable to connect to #{host}: #{e.message}"
          puts
          failed << host
        end
      end

      puts
      puts "Result: #{succeeded.length} successful, #{failed.length} failed"
      puts
      puts 'Failed machines:'
      failed.each { |host| puts "  #{host}" }
    end

    def ssh
      machines = select_machines_with_managed(args[0]).runnable
      raise 'No machines to ssh to' if machines.empty?

      if opts['input-string'] && opts['input-file']
        raise GLI::BadCommandLine, 'use one of --input-string or --input-file'
      end

      if args.length == 1
        raise GLI::BadCommandLine, 'missing command' unless machines.length == 1

        run_ssh_interactive(machines)
        return

      end

      run_ssh_command(machines, args[1..])
    end

    def cssh
      machines = select_machines_with_managed(args[0]).runnable
      raise 'No machines to open cssh to' if machines.empty?

      ask_confirmation! do
        puts 'Open cssh to the following machines:'
        list_machines(machines)
      end

      nix = ConfCtl::Nix.new

      cssh = [
        'cssh',
        '-l', 'root'
      ]

      machines.each_value do |machine|
        cssh << machine.target_host
      end

      nix.run_command_in_shell(
        packages: ['perlPackages.AppClusterSSH'],
        command: cssh.join(' ')
      )
    end

    protected

    attr_reader :wait_online

    def skip_current_deploy_targets(machines, host_generations, action)
      return [machines, host_generations] if opts['copy-only']

      statuses = deploy_target_statuses(machines, host_generations)

      filtered_generations = host_generations.reject do |host, generation|
        machine = machines[host]
        status = statuses[host]

        if already_using_target_generation?(machine, status, generation, action)
          puts Rainbow("Skipping #{host}: already using target generation #{generation.name}").yellow
          true
        else
          false
        end
      end

      filtered_machines = machines.select do |host, _machine|
        filtered_generations.has_key?(host)
      end

      [filtered_machines, filtered_generations]
    end

    def deploy_target_statuses(machines, host_generations)
      statuses = {}
      executor = ConfCtl::ParallelExecutor.new([host_generations.length, 5].min)

      host_generations.each_key do |host|
        statuses[host] = ConfCtl::MachineStatus.new(machines[host])

        executor.add do
          statuses[host].query(toplevel: true, generations: true)
        end
      end

      executor.run
      statuses
    end

    def already_using_target_generation?(machine, status, generation, action)
      return false if status.nil? || status.current_toplevel.nil?

      target_current = status.current_toplevel == generation.toplevel

      return target_current if machine.carried? || %w[test dry-activate].include?(action)
      return target_current && current_profile_toplevel(status) == generation.toplevel if %w[boot switch].include?(action)

      false
    end

    def current_profile_toplevel(status)
      return if status.generations.nil?

      current = status.generations.current
      current && current.toplevel
    end

    def deploy_in_bulk(machines, host_generations, nix, action)
      skipped_copy = []
      skipped_activation = []

      if opts[:interactive]
        host_generations.each do |host, gen|
          if copy_to_host(nix, host, machines[host], gen) == :skip
            puts Rainbow("Skipping #{host}").yellow
            skipped_copy << host
          end
        end
      else
        concurrent_copy(machines, host_generations, nix)
      end

      return if opts['copy-only']

      host_generations.each do |host, gen|
        if skipped_copy.include?(host)
          puts Rainbow("Copy to #{host} was skipped, skipping activation as well").yellow
          skipped_activation << host
          next
        end

        if deploy_to_host(nix, host, machines[host], gen, action) == :skip
          puts Rainbow("Skipping #{host}").yellow
          skipped_activation << host
          next
        end

        puts if opts[:interactive]
      end

      if opts[:reboot]
        host_generations.each_key do |host|
          if skipped_activation.include?(host)
            puts Rainbow("Activation on #{host} was skipped, skipping reboot as well").yellow
            next
          end

          if reboot_host(host, machines[host]) == :skip
            puts "Skipping #{host}"
            next
          end

          puts if opts[:interactive]
        end
      end

      return unless opts['health-checks'] && need_health_checks?(action)

      check_machines = machines.select do |host, _machine|
        if skipped_activation.include?(host)
          puts Rainbow("Activation on #{host} was skipped, skipping health checks as well").yellow
          false
        else
          true
        end
      end

      run_health_check_loop(check_machines)

      puts if opts[:interactive]
    end

    def deploy_one_by_one(machines, host_generations, nix, action)
      host_generations.each do |host, gen|
        machine = machines[host]

        if copy_to_host(nix, host, machine, gen) == :skip
          puts Rainbow("Skipping #{host}").yellow
          next
        end

        next if opts['copy-only']

        if deploy_to_host(nix, host, machine, gen, action) == :skip
          puts Rainbow("Skipping #{host}").yellow
          next
        end

        if opts[:reboot] && reboot_host(host, machine) == :skip
          puts Rainbow("Skipping #{host}").yellow
          next
        end

        if opts['health-checks'] && need_health_checks?(action)
          run_health_check_loop(ConfCtl::MachineList.from_machine(machine))
        end

        puts if opts[:interactive]
      end
    end

    def copy_to_host(nix, host, machine, build_generation)
      puts Rainbow("Copying configuration to #{host} (#{machine.target_host})").yellow

      return :skip if opts[:interactive] && !ask_confirmation(always: true)

      unless ui_enabled?
        ret = nix_copy(nix, machine, build_generation) do |i, n, path|
          puts "[#{host}] [#{i}/#{n}] #{path}"
        end

        raise "Error while copying system to #{host}" unless ret

        return true
      end

      LogView.open(
        header: "#{Rainbow('Copying to').bright} #{host}\n",
        title: Rainbow('Live view').bright
      ) do |lw|
        pb = TTY::ProgressBar.new(
          'Copying [:bar] :current/:total (:percent)',
          width: 80
        )

        ret = nix_copy(nix, machine, build_generation) do |i, n, path|
          lw << "[#{i}/#{n}] #{path}"

          lw.sync_console do
            pb.update(total: n) if pb.total != n
            pb.advance
          end
        end

        raise "Error while copying system to #{host}" unless ret
      end

      true
    end

    def concurrent_copy(machines, host_generations, nix)
      sorted_generations = sort_generations_for_copy(machines, host_generations)

      unless ui_enabled?
        executor = ConfCtl::ParallelExecutor.new(opts['max-concurrent-copy'])

        sorted_generations.each do |host, gen|
          executor.add do
            ret = nix_copy(nix, machines[host], gen) do |i, n, path|
              puts "[#{host}] [#{i}/#{n}] #{path}"
            end

            puts("[#{host}] copy failed") unless ret
            ret ? nil : host
          end
        end

        failed = executor.run.compact
        raise "Copy failed to: #{failed.join(', ')}" if failed.any?

        return
      end

      LogView.open(
        header: "#{Rainbow("Copying to #{sorted_generations.length} machines").bright}\n",
        title: Rainbow('Live view').bright
      ) do |lw|
        multibar = TTY::ProgressBar::Multi.new(
          'Copying [:bar] :current/:total (:percent)',
          width: 80
        )
        executor = ConfCtl::ParallelExecutor.new(opts['max-concurrent-copy'])

        sorted_generations.each do |host, gen|
          pb = multibar.register(
            "#{host} [:bar] :current/:total (:percent)"
          )

          executor.add do
            ret = nix_copy(nix, machines[host], gen) do |i, n, path|
              lw << "#{host}> [#{i}/#{n}] #{path}"

              lw.sync_console do
                if pb.total != n
                  pb.update(total: n)
                  multibar.top_bar.resume if multibar.top_bar.done?
                  multibar.top_bar.update(total: multibar.total)
                end

                pb.advance
              end
            end

            if !ret
              lw.sync_console do
                pb.format = "#{host}: error occurred"
                pb.advance
              end
            elsif pb.total.nil?
              lw.sync_console do
                pb.format = "#{host}: nothing to do"
                pb.advance
              end
            end

            ret ? nil : host
          end
        end

        retvals = executor.run
        failed = retvals.compact

        raise "Copy failed to: #{failed.join(', ')}" if failed.any?
      end
    end

    # Sort generations for copy to target machines
    #
    # This algorithm interleaves carried machines from different carriers,
    # so that we copy to multiple carriers at the same time, and not many carried
    # machines to one carrier.
    def sort_generations_for_copy(machines, host_generations)
      carried, standalone = machines.to_a.partition(&:carried?)

      carried_groups = carried.group_by { |m| m.carrier_machine.name }

      sorted_generations = standalone.map do |m|
        [m.name, host_generations[m.name]]
      end

      until carried_groups.empty?
        carried_groups.delete_if do |_, group_machines|
          m = group_machines.shift
          next(true) if m.nil?

          sorted_generations << [m.name, host_generations[m.name]]

          group_machines.empty?
        end
      end

      if sorted_generations.length != host_generations.length
        raise 'programming error: sorted generations length != original generations'
      end

      sorted_generations
    end

    def deploy_to_host(nix, host, machine, generation, action)
      ret = nil

      LogView.open_with_logger(
        header: "#{Rainbow('Deploying to').bright} #{Rainbow(host).yellow}\n",
        title: Rainbow('Live view').bright,
        size: :auto,
        reserved_lines: 10
      ) do |lw|
        ret =
          if machine.carried?
            deploy_carried_to_host(lw, nix, host, machine, generation, action)
          else
            deploy_standalone_to_host(lw, nix, host, machine, generation, action)
          end

        lw.flush
      end

      ret
    end

    def deploy_standalone_to_host(lw, nix, host, machine, generation, action)
      return :skip if pre_host_activate(lw, nix, host, machine, generation, action) == :skip

      # rubocop:disable Style/GuardClause

      result =
        if %w[test switch].include?(action) && enable_auto_rollback?(machine, generation)
          nix.activate_with_rollback(machine, generation, action)
        else
          nix.activate(machine, generation, action)
        end

      raise "Error while activating configuration on #{host}" unless result

      if %w[boot switch].include?(action) && !nix.set_profile(machine, generation.toplevel)
        raise "Error while setting profile on #{host}"
      end

      # rubocop:enable Style/GuardClause
    end

    def deploy_carried_to_host(lw, nix, host, machine, generation, action)
      return if action != 'switch'

      # rubocop:disable Style/GuardClause
      unless nix.set_carried_profile(machine, generation.toplevel)
        raise "Error while setting carried profile for #{host} on #{machine.carrier_machine}"
      end
      # rubocop:enable Style/GuardClause
    end

    def pre_host_activate(lw, nix, host, machine, generation, action)
      loop do
        if opts['dry-activate-first']
          lw.sync_console do
            puts Rainbow(
              "Trying to activate configuration on #{host} " \
              "(#{machine.target_host})"
            ).yellow
          end

          unless nix.activate(machine, generation, 'dry-activate')
            raise "Error while activating configuration on #{host}"
          end
        end

        lw.sync_console do
          puts Rainbow(
            "Activating configuration on #{host} (#{machine.target_host}): " \
            "#{action}"
          ).yellow
        end

        return unless opts[:interactive]

        options = {}
        options['y'] = 'Continue'
        options['r'] = 'Retry' if opts['dry-activate-first']
        options['s'] = 'Skip'
        options['a'] = 'Abort'

        answer = ask_action(options:, default: nil)

        case answer
        when 'y'
          return
        when 'r'
          next
        when 's'
          return :skip
        when 'a'
          raise 'Aborting'
        end
      end
    end

    def reboot_host(host, machine)
      if machine.localhost?
        puts Rainbow("Skipping reboot of #{host} as it is localhost").yellow
        return :skip
      elsif machine.carried?
        puts Rainbow("Skipping reboot of carried machine #{host}").yellow
        return :skip
      end

      puts Rainbow("Rebooting #{host} (#{machine.target_host})").yellow

      return :skip if opts[:interactive] && !ask_confirmation(always: true)

      m = ConfCtl::MachineControl.new(machine)

      if wait_online == :nowait
        m.reboot
      else
        since = Time.now

        if ui_enabled?
          spinner = nil

          secs = m.reboot_and_wait(
            timeout: wait_online == :wait ? nil : wait_online
          ) do |state, timeleft|
            if state == :reboot
              spinner = TTY::Spinner.new(
                ":spinner Waiting for #{host} (:seconds s)",
                format: :classic
              )
              spinner.auto_spin
            elsif state == :is_up
              spinner.success('up')
              next
            end

            if wait_online == :wait
              spinner.update(seconds: (Time.now - since).round)
            else
              spinner.update(seconds: timeleft.round)
            end
          end
        else
          puts "Waiting for #{host} to reboot..."

          secs = m.reboot_and_wait(
            timeout: wait_online == :wait ? nil : wait_online
          ) do |state, timeleft|
            next unless %i[went_down is_down].include?(state)

            if wait_online == :wait
              puts "  #{host}: waiting #{(Time.now - since).round}s"
            else
              puts "  #{host}: #{timeleft.round}s left"
            end
          end
        end

        puts Rainbow("#{host} (#{machine.target_host}) is online (took #{secs.round(1)}s to reboot)").yellow
      end
    end

    def run_health_check_loop(machines)
      all_checks = machines.health_checks
      return if all_checks.empty?

      run_checks = all_checks

      if opts[:interactive]
        if machines.length > 1
          puts Rainbow("Running #{run_checks.length} health checks on #{machines.length} machines").yellow
        else
          puts Rainbow("Running #{run_checks.length} health checks on #{machines.first}").yellow
        end

        return unless ask_confirmation(always: true)
      end

      loop do
        failed = run_health_checks(machines, run_checks)
        return if failed.empty?

        if opts[:interactive]
          puts 'Health checks have failed'

          answer = ask_action(
            options: {
              'c' => 'Continue',
              'r' => 'Retry all',
              'f' => 'Retry failed',
              'a' => 'Abort'
            },
            default: 'a'
          )

          case answer
          when 'c'
            return
          when 'r'
            run_checks = all_checks
            next
          when 'f'
            run_checks = failed
            next
          when 'a'
            raise 'Aborting'
          end

        elsif opts['keep-going']
          puts 'Health checks have failed, going on'
          return

        else
          raise 'Health checks have failed'
        end
      end
    end

    # @return [Array<HealthChecks::Base>] failed checks
    def run_health_checks(machines, run_checks = nil)
      run_checks ||= machines.health_checks

      tw = ConfCtl::ParallelExecutor.new(opts['max-jobs'] || 5)

      header =
        if machines.length > 1
          Rainbow("Running health checks on #{machines.length} machines").bright
        else
          Rainbow('Running health checks on ').bright + Rainbow(machines.first.to_s).yellow
        end

      header << "\n" << Rainbow('Full log: ').bright << ConfCtl::Logger.relative_path << "\n"

      if ui_enabled?
        LogView.open(
          header:,
          title: Rainbow('Live view').bright,
          size: :auto,
          reserved_lines: 10
        ) do |lw|
          pb = TTY::ProgressBar.new(
            'Checks [:bar] :current/:total (:percent)',
            width: 80,
            total: run_checks.length
          )

          run_checks.each_with_index do |check, i|
            tw.add do
              prefix = "[#{i + 1}/#{run_checks.length}] #{check.machine}> "
              lw << "#{prefix}#{check.description}"

              check.run do |attempt, _errors|
                lw << "#{prefix}failed ##{attempt}: #{check.message}"
                ConfCtl::Logger.keep
              end

              lw << if check.successful?
                      "#{prefix}succeeded"
                    else
                      "#{prefix}error: #{check.message}"
                    end

              lw.sync_console do
                pb.advance
              end
            end
          end

          tw.run
          lw.flush
        end
      else
        puts header

        run_checks.each_with_index do |check, i|
          tw.add do
            prefix = "[#{i + 1}/#{run_checks.length}] #{check.machine}> "
            puts "#{prefix}#{check.description}"

            check.run do |attempt, _errors|
              puts "#{prefix}failed ##{attempt}: #{check.message}"
              ConfCtl::Logger.keep
            end

            puts(
              if check.successful?
                "#{prefix}succeeded"
              else
                "#{prefix}error: #{check.message}"
              end
            )
          end
        end

        tw.run
      end

      successful = []
      failed = []

      run_checks.each do |check|
        if check.successful?
          successful << check
        else
          failed << check
        end
      end

      puts "#{successful.length} checks passed, #{failed.length} failed"
      puts

      failed_by_machine = {}

      failed.each do |check|
        failed_by_machine[check.machine] ||= []
        failed_by_machine[check.machine] << check
      end

      failed_by_machine.each do |machine, checks|
        puts "#{machine}: #{checks.length} failures"

        checks.each do |check|
          puts "  #{check.message}"
        end

        puts
      end

      failed
    end

    def need_health_checks?(action)
      %w[switch test].include?(action) || (action == 'boot' && opts[:reboot])
    end

    def run_ssh_interactive(machines)
      raise ArgumentError if machines.length != 1

      ask_confirmation! do
        puts 'Open interactive shell on the following machine:'
        list_machines(machines)
      end

      machine = machines.first
      mc = ConfCtl::MachineControl.new(machine)
      mc.interactive_shell
    end

    def run_ssh_command(machines, cmd)
      ask_confirmation! do
        puts 'Run command over SSH on the following machines:'
        list_machines(machines)
        puts
        puts "Command: #{Shellwords.join(cmd)}"
      end

      if opts[:parallel]
        run_ssh_command_in_parallel(machines, cmd)
      else
        run_ssh_command_one_by_one(machines, cmd)
      end
    end

    def run_ssh_command_one_by_one(machines, cmd)
      aggregate = opts[:aggregate]
      results = {}

      machines.each do |host, machine|
        mc = ConfCtl::MachineControl.new(machine)

        puts "#{host}:" unless aggregate

        result = run_ssh_command_on_machine(mc, cmd)

        if aggregate
          results[host] = result
        elsif result.success?
          puts result.out
        else
          puts result.err
        end

        puts unless aggregate
      end

      return unless aggregate

      process_aggregated_results(results)
    end

    def run_ssh_command_in_parallel(machines, cmd)
      aggregate = opts[:aggregate]
      results = {}
      tw = ConfCtl::ParallelExecutor.new(machines.length)

      if ui_enabled?
        LogView.open_with_logger(
          header: Rainbow('Executing').bright + " #{Shellwords.join(cmd)}\n",
          title: Rainbow('Live view').bright,
          size: :auto,
          reserved_lines: 10
        ) do |lw|
          pb = TTY::ProgressBar.new(
            'Command [:bar] :current/:total (:percent)',
            width: 80,
            total: machines.length
          )

          machines.each do |host, machine|
            tw.add do
              mc = ConfCtl::MachineControl.new(machine)

              result = run_ssh_command_on_machine(mc, cmd)
              results[host] = result

              lw.sync_console { pb.advance }
            end
          end

          tw.run
          lw.flush
        end
      else
        puts "Executing #{Shellwords.join(cmd)} on #{machines.length} machines"

        machines.each do |host, machine|
          tw.add do
            mc = ConfCtl::MachineControl.new(machine)
            results[host] = run_ssh_command_on_machine(mc, cmd)
          end
        end

        tw.run
      end

      if aggregate
        process_aggregated_results(results)
        return
      end

      results.each do |host, result|
        puts "#{host}:"

        if result.success?
          puts result.out
        else
          puts result.err
        end

        puts
      end
    end

    def run_ssh_command_on_machine(mc, cmd)
      cmd_opts = { err: :out }

      if opts['input-string']
        cmd_opts[:input] = opts['input-string']
      elsif opts['input-file']
        cmd_opts[:in] = opts['input-file']
      end

      mc.execute!(*cmd, **cmd_opts)
    end

    def process_aggregated_results(results)
      groups = {}

      results.each do |host, result|
        key = [result.exit_status, result.out]
        groups[key] ||= []
        groups[key] << host
      end

      groups.each do |key, hosts|
        exit_status, out = key
        puts "#{hosts.sort.join(', ')}:"
        puts "Exit status: #{exit_status}"
        puts out
        puts
      end
    end

    def find_generations(machines, generation_name)
      host_generations = {}
      missing_hosts = []
      generation_offset = generation_name.to_i if /\A-?\d+\z/ =~ generation_name

      machines.each_key do |host|
        list = ConfCtl::Generation::BuildList.new(host)

        gen =
          if generation_offset
            list.at_offset(generation_offset)
          elsif generation_name == 'current'
            list.select_current!
          else
            list[generation_name]
          end

        if gen
          host_generations[host] = gen
        else
          missing_hosts << host
        end
      end

      raise 'No generation found' if host_generations.empty?

      puts 'Resolved host generations:'
      list_generations(host_generations, missing_hosts:)

      if opts[:interactive]
        ask_confirmation!
      else
        puts
      end

      if missing_hosts.any?
        ask_confirmation!(always: opts[:interactive]) do
          puts "Generation '#{generation_name}' was not found on the following hosts:"
          missing_hosts.each { |host| puts "  #{host}" }
          puts
          puts 'These hosts will be ignored.'
        end
      end

      host_generations
    end

    def list_generations(host_generations, missing_hosts:)
      input_roles = []

      host_generations.each_value do |gen|
        inputs_info = normalized_inputs_info(gen)
        next if inputs_info.nil? || inputs_info.empty?

        inputs_info.each_key do |role|
          input_roles << role unless input_roles.include?(role)
        end
      end

      input_column_names = {}
      input_columns = input_roles.map do |role|
        name = role
        input_column_names[role] = name
        { name: name, label: role.to_s.upcase }
      end

      rows = host_generations.map do |host, gen|
        row = {
          'name' => host,
          'generation' => gen.name,
          'kernel' => gen.kernel_version
        }

        inputs_info = normalized_inputs_info(gen) || {}
        input_roles.each do |role|
          row[input_column_names[role]] = inputs_short_rev(inputs_info[role])
        end

        row
      end

      missing_hosts.each do |host|
        rows << { 'name' => host, 'generation' => 'not found' }
      end

      OutputFormatter.print(
        rows,
        %w[name generation kernel] + input_columns,
        layout: :columns,
        sort: %w[name generation]
      )
    end

    def do_build(machines)
      nix = ConfCtl::Nix.new(
        show_trace: opts['show-trace'],
        max_jobs: opts['max-jobs'],
        cores: opts['cores']
      )

      puts Rainbow("Evaluating inputs for #{machines.length} machines...").bright
      hosts_input_paths = nix.eval_host_inputs(machines.map { |host, _| host })

      grps = input_build_groups(hosts_input_paths, nix)
      puts
      puts "Machines will be built in #{grps.length} groups"
      puts
      host_generations = {}
      time = Time.now

      puts "#{Rainbow('Build log:').yellow} #{Rainbow(ConfCtl::Logger.path).cyan}"
      puts

      grps.each_with_index do |grp, i|
        hosts, input_paths = grp

        built_generations = do_build_group(
          i,
          grps.length,
          hosts,
          input_paths,
          nix,
          time
        )

        host_generations.update(built_generations)
      end

      generation_hosts = {}

      host_generations.each do |host, gen|
        generation_hosts[gen.name] ||= []
        generation_hosts[gen.name] << host
      end

      puts
      puts Rainbow('Built generations:').bright
      generation_hosts.each do |gen, hosts|
        puts Rainbow(gen).cyan
        hosts.each { |host| puts "  #{host}" }
      end

      host_generations
    end

    def do_build_group(group_index, group_count, hosts, input_paths, nix, time)
      puts Rainbow('Building machines').bright
      hosts.each { |h| puts "  #{h}" }
      puts 'with inputs'
      input_paths.each { |k, v| puts "  #{k}=#{v}" }

      header = '' \
        << Rainbow('Command:').bright \
        << " #{format_command(10)}" \
        << "\n" \
        << Rainbow('Build group:').bright \
        << " #{group_index + 1}/#{group_count} (#{hosts.length} machines)" \
        << "\n" \
        << Rainbow('Full log:   ').bright \
        << " #{ConfCtl::Logger.relative_path}" \
        << "\n\n"

      if ui_enabled?
        LogView.open_with_logger(
          header:,
          title: Rainbow('Live view').bright,
          size: :auto,
          reserved_lines: 10
        ) do |lw|
          multibar = TTY::ProgressBar::Multi.new(
            'nix build [:bar] :current/:total (:percent)',
            width: 80
          )

          build_pb = multibar.register(
            'Building [:bar] :current/:total (:percent)'
          )

          fetch_pb = multibar.register(
            'Fetching [:bar] :current/:total (:percent)'
          )

          built_generations = nix.build_attributes(
            hosts:,
            time:
          ) do |type, _progress, total, _path|
            if type == :build
              lw.sync_console do
                build_pb.update(total:) if total > 0 && build_pb.total.nil?
                build_pb.advance
              end
            elsif type == :fetch
              lw.sync_console do
                fetch_pb.update(total:) if total > 0 && fetch_pb.total.nil?
                fetch_pb.advance
              end
            end

            if build_pb.total && fetch_pb.total && multibar.top_bar.total.nil?
              lw.sync_console do
                multibar.top_bar.update(total: multibar.total)
              end
            end
          end

          built_generations
        end
      else
        puts header
        nix.build_attributes(
          hosts:,
          time:
        ) do |type, progress, total, path|
          puts "[#{type}] #{progress}/#{total} #{path}"
        end
      end
    end

    def input_build_groups(hosts_inputs, nix)
      return [[hosts_inputs.keys, {}]] unless nix.confctl_settings.dig('nix', 'legacyNixPath') == true

      hosts_inputs.values.uniq.map do |inputs|
        [hosts_inputs.select { |_host, paths| paths == inputs }.keys, inputs]
      end
    end

    def compare_inputs_info
      machines = select_machines(args[0]).managed

      ask_confirmation! do
        puts 'Compare inputs on the following machines:'
        list_machines(machines)
        puts
        puts "Generation: #{opts[:generation] || 'current configuration'}"
      end

      statuses = machines.transform_values do |machine|
        ConfCtl::MachineStatus.new(machine)
      end

      if opts[:generation]
        host_generations = find_generations(machines, opts[:generation])

        # Ignore statuses when no generation was found
        statuses.delete_if do |host, _st|
          !host_generations.has_key?(host)
        end

        assign_target_inputs_info(statuses, host_generations:)
      else
        assign_target_inputs_info(statuses)
      end

      TTY::Pager.page(enabled: use_pager?) do |io|
        statuses.each do |host, st|
          st.query(toplevel: false, generations: false, inputs: true)

          if st.uptime.nil?
            io.puts "#{host} is offline"
            next
          end

          target_info = st.target_inputs_info || {}
          deployed_info = st.inputs_info || {}

          yield(io, host, target_info, deployed_info)
        end
      end
    end

    def assign_target_inputs_info(statuses, host_generations: nil)
      if host_generations
        host_generations.each do |host, gen|
          next unless statuses[host]

          statuses[host].target_inputs_info = ConfCtl::InputsInfo.normalize(gen.inputs_info)
        end
      else
        nix = ConfCtl::Nix.new(show_trace: opts['show-trace'])

        statuses.each do |host, st|
          st.target_inputs_info = ConfCtl::InputsInfo.normalize(nix.eval_inputs_info(host))
        rescue StandardError
          st.target_inputs_info = nil
        end
      end
    end

    def inputs_roles_for_status(statuses)
      roles = []

      statuses.each_value do |st|
        roles.concat((st.target_inputs_info || {}).keys)
        roles.concat((st.inputs_info || {}).keys)
      end

      roles.uniq.sort
    end

    def inputs_ok?(status)
      target_info = status.target_inputs_info
      return false if target_info.nil? || target_info.empty?

      target_info.all? do |role, info|
        inputs_info_state(info, status.inputs_info && status.inputs_info[role]) == :same
      end
    end

    def inputs_info_entries(target_info, deployed_info, pattern: nil)
      inputs_roles(target_info, deployed_info).filter_map do |role|
        next if pattern && !ConfCtl::Pattern.match?(pattern, role)

        t_info = target_info[role]
        d_info = deployed_info[role]
        { role:, target: t_info, deployed: d_info, status: inputs_info_state(t_info, d_info) }
      end
    end

    def inputs_roles(target_info, deployed_info)
      roles = []
      roles.concat(target_info.keys) if target_info
      roles.concat(deployed_info.keys) if deployed_info
      roles.uniq.sort
    end

    def inputs_info_state(target_info, deployed_info)
      return :unknown if target_info.nil? || deployed_info.nil?

      target_rev = inputs_rev(target_info)
      deployed_rev = inputs_rev(deployed_info)
      return :unknown if target_rev.nil? || deployed_rev.nil?

      target_rev == deployed_rev ? :same : :changed
    end

    def inputs_rev(info)
      return nil unless info.is_a?(Hash)

      info['rev']
    end

    def inputs_short_rev(info)
      return nil unless info.is_a?(Hash)

      info['shortRev'] || (info['rev'] && info['rev'][0, 8])
    end

    def normalized_inputs_info(gen)
      return nil unless gen.respond_to?(:inputs_info)

      ConfCtl::InputsInfo.normalize(gen.inputs_info)
    end

    def inputs_url(target_info, deployed_info)
      (target_info && target_info['url']) || (deployed_info && deployed_info['url'])
    end

    def inputs_git_log(target_info, deployed_info)
      url = inputs_url(target_info, deployed_info)
      old_rev = inputs_rev(deployed_info)
      new_rev = inputs_rev(target_info)
      return nil if url.nil? || old_rev.nil? || new_rev.nil?

      old_rev, new_rev = new_rev, old_rev if opts[:downgrade]

      log_opts = []
      log_opts << '--oneline' unless opts[:verbose]
      log_opts << '-p' if opts[:patch]
      log_opts << '--max-count=50' unless opts[:verbose] || opts[:patch]

      mirror = ConfCtl::GitRepoMirror.new(url, quiet: true)
      mirror.setup
      mirror.log(old_rev, new_rev, opts: log_opts)
    end

    def format_inputs_state(state, deployed_info)
      rev = inputs_short_rev(deployed_info) || 'unknown'

      case state
      when :same
        Rainbow(rev).green
      when :changed
        Rainbow(rev).red
      else
        Rainbow(rev).yellow
      end
    end

    def parse_wait_online
      @wait_online =
        case opts['wait-online']
        when 'wait'
          :wait
        when 'nowait'
          :nowait
        when /^\d+$/
          opts['wait-online'].to_i
        else
          raise GLI::BadCommandLine, 'invalid value of --wait-online'
        end
    end

    def format_command(reserved_cols = 0)
      cmd = "#{$0.split('/').last} #{ARGV.join(' ')}"
      cols = IO.console&.winsize&.last
      cols = cols.to_i
      cols = 80 if cols <= 0
      max_length = cols - reserved_cols

      return cmd if max_length <= 4

      if cmd.length > max_length
        "#{cmd[0..(max_length - 4)]}..."
      else
        cmd
      end
    end

    def format_duration(interval)
      {
        'd' => 24 * 60 * 60,
        'h' => 60 * 60,
        'm' => 60,
        's' => 1
      }.each do |unit, n|
        return "#{(interval / n.to_f).round(1)}#{unit}" if interval > n
      end

      raise ArgumentError, "invalid time duration '#{interval}'"
    end

    # @param nix [Nix]
    # @param machine [Machine]
    # @param generation [Generation::Build]
    def nix_copy(nix, machine, generation, &)
      paths = [generation.toplevel]
      paths << generation.auto_rollback if enable_auto_rollback?(machine, generation)

      nix.copy(machine, paths, &)
    end

    def ui_enabled?
      ConfCtl::Ui.tty?
    end

    def enable_auto_rollback?(machine, generation)
      !opts['disable-auto-rollback'] \
        && (opts['enable-auto-rollback'] || machine.auto_rollback?) \
        && generation.auto_rollback
    end
  end
end
