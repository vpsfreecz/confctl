{
  config,
  lib,
  confLib,
  ...
}@args:
with lib;
let
  machine =
    { config, ... }:
    {
      options = {
        managed = mkOption {
          type = types.nullOr types.bool;
          default = null;
          apply =
            v:
            if !isNull v then
              v
            else if
              elem config.spin [
                "nixos"
                "vpsadminos"
              ]
            then
              true
            else
              false;
          description = ''
            Determines whether the machine is managed using confctl or not

            By default, NixOS and vpsAdminOS machines are managed by confctl.
          '';
        };

        spin = mkOption {
          type = types.enum [
            "openvz"
            "nixos"
            "vpsadminos"
            "other"
          ];
          description = "OS type";
        };

        inputs = {
          channels = mkOption {
            type = types.listOf types.str;
            default = [ ];
            description = ''
              List of flake input channels to use on this machine.

              This selects entries from the `channels` mapping
              passed to `mkConfctlOutputs` (e.g. "production", "staging", "os-staging").
            '';
          };

          overrides = mkOption {
            type = types.attrsOf types.str;
            default = { };
            description = ''
              Override role -> flake input mapping for this machine
            '';
          };
        };

        addresses = mkOption {
          type = types.nullOr (types.submodule addresses);
          default = { };
          description = ''
            IP addresses
          '';
        };

        netboot = {
          enable = mkEnableOption "Include this system on pxe servers";
          macs = mkOption {
            type = types.listOf types.str;
            default = [ ];
            description = ''
              List of MAC addresses for iPXE node auto-detection
            '';
          };
        };

        buildAttribute = mkOption {
          type = types.listOf types.str;
          default = [
            "system"
            "build"
            "toplevel"
          ];
          description = ''
            Path to the attribute in machine system config that should be built

            For example, `[ "system" "build" "toplevel" ]` will select attribute
            `config.system.build.toplevel`.
          '';
        };

        carrier = {
          enable = mkEnableOption "This machine is a carrier for other machines";

          machines = mkOption {
            type = types.listOf (types.submodule carriedMachine);
            default = [ ];
            description = ''
              List of carried machines
            '';
          };
        };

        host = mkOption {
          type = types.nullOr (types.submodule host);
          default = null;
        };

        labels = mkOption {
          type = types.attrs;
          default = { };
          description = ''
            Optional user-defined labels to classify the machine
          '';
        };

        tags = mkOption {
          type = types.listOf types.str;
          default = [ ];
          description = ''
            Optional user-defined tags to classify the machine
          '';
        };

        buildGenerations = {
          min = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The minimum number of build generations to be kept on the build
              machine.
            '';
          };

          max = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The maximum number of build generations to be kept on the build
              machine.
            '';
          };

          maxAge = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              Delete build generations older than
              <option>cluster.&lt;name&gt;.buildGenerations.maxAge</option>
              seconds from the build machine. Old generations are deleted even
              if <option>cluster.&lt;name&gt;.buildGenerations.max</option> is
              not reached.
            '';
          };
        };

        hostGenerations = {
          min = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The minimum number of generations to be kept on the machine.
            '';
          };

          max = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The maximum number of generations to be kept on the machine.
            '';
          };

          maxAge = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              Delete generations older than
              <option>cluster.&lt;name&gt;.hostGenerations.maxAge</option>
              seconds from the machine. Old generations are deleted even
              if <option>cluster.&lt;name&gt;.hostGenerations.max</option> is
              not reached.
            '';
          };

          collectGarbage = mkOption {
            type = types.nullOr types.bool;
            default = null;
            description = "Run nix-collect-garbage";
          };
        };

        autoRollback = {
          enable = mkOption {
            type = types.bool;
            default = true;
            description = ''
              Enable automatic rollback in case the machine is unresponsive after
              deploy
            '';
          };

          timeout = mkOption {
            type = types.int;
            default = 60;
            description = ''
              Number of seconds after which if the machine is unreachable, auto-rollback
              is initiated
            '';
          };
        };

        healthChecks = {
          systemd = {
            enable = mkOption {
              type = types.bool;
              default = true;
              description = ''
                Enable systemd checks, enabled by default
              '';
            };

            systemProperties = mkOption {
              type = types.listOf (types.submodule systemdProperty);
              default = [
                {
                  property = "SystemState";
                  value = "running";
                }
              ];
              description = ''
                Check systemd manager properties reported by systemctl show
              '';
            };

            unitProperties = mkOption {
              type = types.attrsOf (types.listOf (types.submodule systemdProperty));
              default = { };
              example = literalExpression ''
                {
                  "firewall.service" = [
                    { property = "ActiveState"; value = "active"; }
                  ];
                }
              '';
              description = ''
                Check systemd unit properties reported by systemctl show <literal>&lt;unit&gt;</literal>
              '';
            };
          };

          builderCommands = mkOption {
            type = types.listOf (types.submodule checkCommand);
            default = [ ];
            example = literalExpression ''
              [
                { description = "ping"; command = [ "ping" "-c1" "{host.fqdn}" ]; }
              ]
            '';
            description = ''
              Check commands run on the build machine
            '';
          };

          machineCommands = mkOption {
            type = types.listOf (types.submodule checkCommand);
            default = [ ];
            example = literalExpression ''
              [
                { description = "curl"; command = [ "curl" "-s" "http://localhost:80" ]; }
              ]
            '';
            description = ''
              Check commands run on the target machine

              Note that the commands have to be available on the machine.
            '';
          };
        };
      };
    };

  addresses =
    { config, ... }:
    {
      options = {
        primary = mkOption {
          type = types.nullOr (types.submodule (confLib.mkOptions.addresses 4));
          default =
            if config.v4 != [ ] then
              head config.v4
            else if config.v6 != [ ] then
              head config.v6
            else
              null;
          description = ''
            Default address other machines should use to connect to this machine

            Defaults to the first IPv4 address if not set
          '';
        };

        v4 = mkOption {
          type = types.listOf (types.submodule (confLib.mkOptions.addresses 4));
          default = [ ];
          description = ''
            List of IPv4 addresses this machine responds to
          '';
        };

        v6 = mkOption {
          type = types.listOf (types.submodule (confLib.mkOptions.addresses 6));
          default = [ ];
          description = ''
            List of IPv6 addresses this machine responds to
          '';
        };
      };
    };

  host =
    { config, ... }:
    {
      options = {
        name = mkOption {
          type = types.nullOr types.str;
          default = null;
          description = ''
            Host name
          '';
        };

        location = mkOption {
          type = types.nullOr types.str;
          default = null;
          description = ''
            Host location domain
          '';
        };

        domain = mkOption {
          type = types.nullOr types.str;
          default = null;
          description = ''
            Host domain
          '';
        };

        fullDomain = mkOption {
          type = types.nullOr types.str;
          default = null;
          description = ''
            Domain including location, i.e. FQDN without host name
          '';
          apply =
            v:
            if isNull v && !isNull config.domain then
              concatStringsSep "." ((optional (!isNull config.location) config.location) ++ [ config.domain ])
            else
              v;
        };

        fqdn = mkOption {
          type = types.nullOr types.str;
          default = null;
          description = ''
            Host FQDN
          '';
          apply =
            v:
            if isNull v && !isNull config.name then
              concatStringsSep "." (
                [ config.name ]
                ++ (optional (!isNull config.location) config.location)
                ++ (optional (!isNull config.domain) config.domain)
              )
            else
              v;
        };

        target = mkOption {
          type = types.nullOr types.str;
          default = config.fqdn;
          description = ''
            Address/host to which the configuration is deployed to

            Set to null if the machine is not deployable, e.g. when it is only used
            as a carried machine.
          '';
        };

        port = mkOption {
          type = types.int;
          default = 22;
          description = ''
            SSH port used to connect to this machine.
          '';
        };
      };
    };

  carriedMachine =
    { config, ... }:
    {
      options = {
        machine = mkOption {
          type = types.str;
          description = "Machine name";
        };

        alias = mkOption {
          type = types.nullOr types.str;
          description = "Alias for carried machine name";
        };

        labels = mkOption {
          type = types.attrs;
          default = { };
          description = ''
            Optional user-defined labels to classify the machine
          '';
        };

        tags = mkOption {
          type = types.listOf types.str;
          default = [ ];
          description = ''
            Optional user-defined tags to classify the machine
          '';
        };

        extraModules = mkOption {
          type = types.listOf types.path;
          default = [ ];
          description = ''
            A list of additional NixOS modules to be imported for this machine
          '';
        };

        buildAttribute = mkOption {
          type = types.listOf types.str;
          default = [
            "system"
            "build"
            "toplevel"
          ];
          description = ''
            Path to the attribute in machine system config that should be built

            For example, `[ "system" "build" "toplevel" ]` will select attribute
            `config.system.build.toplevel`.
          '';
        };

        buildGenerations = {
          min = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The minimum number of build generations to be kept on the build
              machine.
            '';
          };

          max = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The maximum number of build generations to be kept on the build
              machine.
            '';
          };

          maxAge = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              Delete build generations older than
              <option>cluster.&lt;name&gt;.carrier.machines.*.buildGenerations.maxAge</option>
              seconds from the build machine. Old generations are deleted even
              if <option>cluster.&lt;name&gt;.carrier.machines.*.buildGenerations.max</option> is
              not reached.
            '';
          };
        };

        hostGenerations = {
          min = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The minimum number of generations to be kept on the machine.
            '';
          };

          max = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              The maximum number of generations to be kept on the machine.
            '';
          };

          maxAge = mkOption {
            type = types.nullOr types.int;
            default = null;
            description = ''
              Delete generations older than
              <option>cluster.&lt;name&gt;.carrier.machines.*.hostGenerations.maxAge</option>
              seconds from the machine. Old generations are deleted even
              if <option>cluster.&lt;name&gt;.carrier.machines.*.hostGenerations.max</option> is
              not reached.
            '';
          };
        };
      };
    };

  systemdProperty =
    { config, ... }:
    {
      options = {
        property = mkOption {
          type = types.str;
          description = "systemd property name";
        };

        value = mkOption {
          type = types.str;
          description = "value to be checked";
        };

        timeout = mkOption {
          type = types.ints.unsigned;
          default = 60;
          description = "Max number of seconds to wait for the check to pass";
        };

        cooldown = mkOption {
          type = types.ints.unsigned;
          default = 3;
          description = "Number of seconds in between check attempts";
        };
      };
    };

  checkCommand =
    { config, ... }:
    {
      options = {
        description = mkOption {
          type = types.str;
          default = "";
          description = "Command description";
        };

        command = mkOption {
          type = types.listOf types.str;
          description = ''
            Command and its arguments

            It is possible to access machine attributes as from CLI using curly
            brackets. For example, {host.fqdn} would be replaced by machine FQDN.
            See confctl ls -L for a list of available attributes.
          '';
        };

        exitStatus = mkOption {
          type = types.ints.unsigned;
          default = 0;
          description = "Expected exit status";
        };

        standardOutput = {
          match = mkOption {
            type = types.nullOr types.str;
            default = null;
            description = "Standard output must match this string";
          };

          include = mkOption {
            type = types.listOf types.str;
            default = [ ];
            description = "Strings that must be included in standard output";
          };

          exclude = mkOption {
            type = types.listOf types.str;
            default = [ ];
            description = "Strings that must not be included in standard output";
          };
        };

        standardError = {
          match = mkOption {
            type = types.nullOr types.str;
            default = null;
            description = "Standard error must match this string";
          };

          include = mkOption {
            type = types.listOf types.str;
            default = [ ];
            description = "String that must be included in standard error";
          };

          exclude = mkOption {
            type = types.listOf types.str;
            default = [ ];
            description = "String that must not be included in standard error";
          };
        };

        timeout = mkOption {
          type = types.ints.unsigned;
          default = 60;
          description = "Max number of seconds to wait for the check to pass";
        };

        cooldown = mkOption {
          type = types.ints.unsigned;
          default = 3;
          description = "Number of seconds in between check attempts";
        };
      };
    };
in
{
  options = {
    cluster = mkOption {
      type = types.attrsOf (types.submodule machine);
      default = { };
    };
  };
}
