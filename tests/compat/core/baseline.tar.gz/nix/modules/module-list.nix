let
  shared = [
    ./cluster
    ./confctl/generations.nix
    ./confctl/cli.nix
    ./confctl/nix.nix
    ./confctl/inputs-info.nix
    ./confctl/configuration-info.nix
  ];

  nixos = [
  ];

  vpsadminos = [
  ];
in
{
  nixos = shared ++ nixos;
  vpsadminos = shared ++ vpsadminos;
  all = shared ++ nixos ++ vpsadminos;
}
